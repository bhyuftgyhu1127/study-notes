package com.lagou.jenkinsdemo1.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JenkinsDemo1Controller {
    @GetMapping("/")
    public String hello() {
        return "docker-maven-plugins hello!!!";
    }
}
