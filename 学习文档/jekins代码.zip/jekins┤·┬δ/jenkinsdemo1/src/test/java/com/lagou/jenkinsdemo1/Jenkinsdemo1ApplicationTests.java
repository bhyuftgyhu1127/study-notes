package com.lagou.jenkinsdemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jenkinsdemo1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
