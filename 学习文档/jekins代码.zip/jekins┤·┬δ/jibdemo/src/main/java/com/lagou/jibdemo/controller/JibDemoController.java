package com.lagou.jibdemo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JibDemoController {

    @GetMapping("/")
    public String hello() {
        return "google起名字就是霸气！！";
    }

}
