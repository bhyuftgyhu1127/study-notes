package com.lagou.jibdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JibdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(JibdemoApplication.class, args);
    }

}
