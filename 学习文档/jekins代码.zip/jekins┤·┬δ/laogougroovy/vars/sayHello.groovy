def call(String name="laosiji") {
    println("hello $name")
}