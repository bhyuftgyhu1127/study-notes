package com.lagou.hello

def printMessage() {
    println("hello laosiji")
}
