package com.lagou.hello

class HelloGroovy {
    public static void main(String[] args) {
        String name = "laosiji"
        println("groovy 大爷你好!"+name+"给您请安啦!!")
        println('hello groovy');


    }
}
