package com.lagou.test;

public class AgentTest1 {
    public static void main(String[] args) {
        System.out.println("这是我们的第一个agent项目，这里是main方法工程测试。");
        sayHello1();
        sayHello2("1","2");
    }

    static void sayHello1() {
        System.out.println("java ssist hello!!!");
    }

    static void sayHello2(String str1,String str2) {
        System.out.println(str1+"\t"+str2);
    }
}
