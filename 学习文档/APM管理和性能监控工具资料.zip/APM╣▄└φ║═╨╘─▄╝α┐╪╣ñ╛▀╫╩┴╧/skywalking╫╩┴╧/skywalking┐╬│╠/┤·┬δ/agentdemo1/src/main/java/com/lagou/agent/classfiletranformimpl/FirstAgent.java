package com.lagou.agent.classfiletranformimpl;

import javassist.*;
import javassist.bytecode.CodeAttribute;

import java.io.IOException;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

public class FirstAgent implements ClassFileTransformer {
    public static final String INJECTEDCLASSNAME="com.lagou.test";
    @Override
    public byte[] transform(ClassLoader loader,
                            String className,
                            Class<?> classBeingRedefined,
                            ProtectionDomain protectionDomain,
                            byte[] classfileBuffer)
            throws IllegalClassFormatException {
        //把"/"替换成"."
        className = className.replace("/", ".");
        if(className.startsWith(INJECTEDCLASSNAME)){
            //使用className,获取字节码的类
            CtClass ctClass = null;

            try {
                ctClass = ClassPool.getDefault().get(className);
                CtMethod[] ctMethods = ctClass.getMethods();
                for(CtMethod ctMethod: ctMethods){
                    CodeAttribute ca = ctMethod.getMethodInfo2().getCodeAttribute();
                    if(ca == null){
                        continue;
                    }
                    if(!ctMethod.isEmpty()){
                        ctMethod.insertBefore("System.out.println(\"hello im agent :"+ctMethod.getName()+"\");");

                    }
                }
                return ctClass.toBytecode();
            } catch (NotFoundException e) {
                e.printStackTrace();
            } catch (CannotCompileException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return null;
    }
}
