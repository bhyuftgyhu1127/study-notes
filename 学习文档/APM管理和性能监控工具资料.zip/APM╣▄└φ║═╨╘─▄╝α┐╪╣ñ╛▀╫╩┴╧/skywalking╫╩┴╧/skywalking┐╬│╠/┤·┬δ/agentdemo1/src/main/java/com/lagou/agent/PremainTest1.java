package com.lagou.agent;

import com.lagou.agent.classfiletranformimpl.FirstAgent;

import java.lang.instrument.Instrumentation;

public class PremainTest1 {

    public static void premain(String agentArgs, Instrumentation inst) {
        System.out.println("hello javaagent demo1!");
        System.out.println("agentArgs ====> " + agentArgs);
        inst.addTransformer(new FirstAgent());
    }


    public static void premain(String agentArgs) {
        System.out.println("hello javaagent demo2!");
        System.out.println("agentArgs ====> " + agentArgs);
    }
}
