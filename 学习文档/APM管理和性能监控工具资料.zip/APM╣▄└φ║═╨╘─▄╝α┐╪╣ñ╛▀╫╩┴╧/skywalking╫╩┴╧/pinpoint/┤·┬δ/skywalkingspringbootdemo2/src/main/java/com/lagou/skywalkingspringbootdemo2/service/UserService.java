package com.lagou.skywalkingspringbootdemo2.service;

import com.lagou.skywalkingspringbootdemo2.entity.Tbuser;

import java.util.List;

public interface UserService {
    List<Tbuser> queryUsers();
}
