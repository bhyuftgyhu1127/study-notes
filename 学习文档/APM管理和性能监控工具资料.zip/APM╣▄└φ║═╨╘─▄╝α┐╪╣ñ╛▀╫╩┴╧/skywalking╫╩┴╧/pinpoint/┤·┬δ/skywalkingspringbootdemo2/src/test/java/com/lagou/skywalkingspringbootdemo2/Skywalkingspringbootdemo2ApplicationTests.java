package com.lagou.skywalkingspringbootdemo2;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

@SpringBootTest(classes = Skywalkingspringbootdemo2Application.class)
@ExtendWith(SpringExtension.class)
public class Skywalkingspringbootdemo2ApplicationTests {


}
