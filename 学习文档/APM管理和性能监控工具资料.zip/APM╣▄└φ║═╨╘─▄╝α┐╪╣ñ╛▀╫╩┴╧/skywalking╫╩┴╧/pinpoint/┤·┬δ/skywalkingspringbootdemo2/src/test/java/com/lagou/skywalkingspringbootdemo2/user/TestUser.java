package com.lagou.skywalkingspringbootdemo2.user;

import com.lagou.skywalkingspringbootdemo2.Skywalkingspringbootdemo2ApplicationTests;
import com.lagou.skywalkingspringbootdemo2.entity.Tbuser;
import com.lagou.skywalkingspringbootdemo2.service.UserService;
import org.junit.jupiter.api.Test;

import javax.annotation.Resource;
import java.util.List;

public class TestUser extends Skywalkingspringbootdemo2ApplicationTests {

    @Resource
    private UserService userService;

    @Test
    public void testQueryUsers() {
        List<Tbuser> tbusers = this.userService.queryUsers();
    }
}
