package com.lagou.skywalkingspringbootdemo2.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.lagou.skywalkingspringbootdemo2.entity.Tbuser;

public interface UserMapper extends BaseMapper<Tbuser> {
}
