package com.lagou.skywalkingspringbootdemo2;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "com.lagou.skywalkingspringbootdemo2.mapper")
public class Skywalkingspringbootdemo2Application {

	public static void main(String[] args) {
		SpringApplication.run(Skywalkingspringbootdemo2Application.class, args);
	}

}
