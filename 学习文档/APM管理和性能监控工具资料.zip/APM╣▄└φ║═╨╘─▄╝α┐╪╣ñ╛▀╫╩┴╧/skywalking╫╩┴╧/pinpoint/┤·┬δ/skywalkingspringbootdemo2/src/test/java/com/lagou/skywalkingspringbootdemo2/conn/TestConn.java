package com.lagou.skywalkingspringbootdemo2.conn;

import com.lagou.skywalkingspringbootdemo2.Skywalkingspringbootdemo2ApplicationTests;
import org.junit.jupiter.api.Test;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class TestConn extends Skywalkingspringbootdemo2ApplicationTests {

    @Resource
    private DataSource dataSource;

    @Test
    public void testconn() throws SQLException {
        Connection connection = dataSource.getConnection();
        System.out.println("=======>"+connection);
    }

}
