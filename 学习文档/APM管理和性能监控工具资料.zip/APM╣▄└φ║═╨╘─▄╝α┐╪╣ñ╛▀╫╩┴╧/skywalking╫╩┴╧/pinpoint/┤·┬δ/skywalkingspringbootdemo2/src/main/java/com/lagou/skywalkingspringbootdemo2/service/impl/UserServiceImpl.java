package com.lagou.skywalkingspringbootdemo2.service.impl;

import com.lagou.skywalkingspringbootdemo2.entity.Tbuser;
import com.lagou.skywalkingspringbootdemo2.mapper.UserMapper;
import com.lagou.skywalkingspringbootdemo2.service.UserService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
@Service
public class UserServiceImpl implements UserService {

    @Resource
    private UserMapper userMapper;

    @Override
    public List<Tbuser> queryUsers() {
        return this.userMapper.selectList(null);
    }
}
