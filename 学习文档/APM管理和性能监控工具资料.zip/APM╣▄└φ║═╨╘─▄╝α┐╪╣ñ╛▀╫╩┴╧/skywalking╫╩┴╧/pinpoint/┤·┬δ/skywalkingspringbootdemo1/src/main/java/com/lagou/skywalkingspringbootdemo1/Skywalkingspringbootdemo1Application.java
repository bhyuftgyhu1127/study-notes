package com.lagou.skywalkingspringbootdemo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Skywalkingspringbootdemo1Application {

    public static void main(String[] args) {
        SpringApplication.run(Skywalkingspringbootdemo1Application.class, args);
    }

}
