# Solr资料

下载地址：

链接：https://pan.baidu.com/s/1LPPO-yuGpaGEsXi8kUhaMA 
提取码：dae0

资源图片：

![image-20200831115650371](C:\Users\shiguowei\AppData\Roaming\Typora\typora-user-images\image-20200831115650371.png)