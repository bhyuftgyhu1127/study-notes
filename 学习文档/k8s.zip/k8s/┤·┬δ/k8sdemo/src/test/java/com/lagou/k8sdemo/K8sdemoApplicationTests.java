package com.lagou.k8sdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class K8sdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
